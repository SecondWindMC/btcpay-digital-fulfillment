This is a harmless example product file. Replace products/example-product.zip with your real deliverable.
